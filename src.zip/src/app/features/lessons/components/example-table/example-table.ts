import { CommonModule } from '@angular/common';
import { Component, inject, Input } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { Example } from '../../../../models';
import { PracticeModal } from '../../../practice/practice-modal/practice-modal';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-example-table',
  imports: [CommonModule, MatTableModule],
  templateUrl: './example-table.html',
  styleUrl: './example-table.scss',
})
export class ExampleTable {
  @Input({ required: true }) examples: Example[] = [];

  readonly dialog = inject(MatDialog);
  displayedColumns: string[] = ['kanji', 'kana', 'romaji', 'english'];

  ngAfterViewInit() {
    // Add data-label attributes for mobile view
    const cells = document.querySelectorAll('.mat-column-kanji');
    cells.forEach((cell) => cell.setAttribute('data-label', '漢字'));
    // Repeat for other columns...
  }

  openPractice(): void {
    const practiceRef = this.dialog.open(PracticeModal, {
      data: {
        examples: this.examples,
      },
    });

    practiceRef.afterClosed().subscribe((result) => {
      console.log(`Dialog result: ${result}`);
    });
  }
}
