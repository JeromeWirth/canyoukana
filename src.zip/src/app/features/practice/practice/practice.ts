import { Component } from '@angular/core';

@Component({
  selector: 'app-practice',
  imports: [],
  templateUrl: './practice.html',
  styleUrl: './practice.scss'
})
export class Practice {

}
