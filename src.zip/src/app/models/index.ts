export * from './lesson.interface';
export * from './jmdict.interface';
